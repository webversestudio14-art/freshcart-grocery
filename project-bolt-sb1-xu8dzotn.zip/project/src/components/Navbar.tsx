import { useState } from "react";
import { Search, Globe, Menu, User, X } from "lucide-react";

interface NavbarProps {
  onDownload: () => void;
}

export default function Navbar({ onDownload }: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<"stays" | "experiences">("stays");

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main nav row */}
        <div className="flex items-center justify-between h-20 gap-4">
          {/* Logo */}
          <a href="#" className="flex-shrink-0 flex items-center gap-1 group">
            <svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" className="w-9 h-9 fill-[#FF385C]">
              <path d="M16 1c2.008 0 3.463.963 4.751 3.269l.533 1.025c1.954 3.83 6.114 12.54 7.1 14.836l.145.353c.667 1.591.91 2.472.96 3.396l.01.415.001.228c0 4.062-2.877 6.478-6.357 6.478-2.042 0-4.246-1.17-6.22-3.URLException.229l-.1-.011-.169.015c-2.084 1.654-4.326 3.225-6.281 3.225-3.48 0-6.357-2.416-6.357-6.478l.001-.228.01-.415c.05-.924.293-1.805.96-3.396l.145-.353c.985-2.296 5.145-11.007 7.1-14.836l.533-1.025C12.537 1.963 13.992 1 16 1zm0 2c-1.239 0-2.053.539-3.048 2.365l-.527 1.016C10.18 10.227 6.007 19 5.022 21.289l-.14.339c-.6 1.429-.822 2.197-.869 3.02l-.01.398-.001.211c0 2.953 1.987 4.478 4.357 4.478 1.452 0 3.242-.986 5.105-2.562l.31-.27.122-.112.126-.115.11.112.296.272.298.251c1.863 1.555 3.62 2.424 5.034 2.424 2.37 0 4.357-1.525 4.357-4.478l-.001-.211-.01-.398c-.047-.823-.269-1.591-.869-3.02l-.14-.339C25.993 19 21.82 10.227 20.048 6.381l-.527-1.016C18.053 3.539 17.239 3 16 3z"/>
            </svg>
            <span className="text-[#FF385C] font-bold text-xl hidden sm:block tracking-tight">airbnb</span>
          </a>

          {/* Search bar (desktop) */}
          <div className="hidden md:flex flex-1 max-w-xl">
            <div className="flex items-center w-full border border-gray-300 rounded-full shadow-sm hover:shadow-md transition-shadow cursor-pointer group">
              <button className="flex-1 text-left px-5 py-2.5 text-sm font-semibold text-gray-800 hover:bg-gray-50 rounded-l-full transition-colors">
                Anywhere
              </button>
              <div className="w-px h-5 bg-gray-300" />
              <button className="flex-1 text-left px-5 py-2.5 text-sm font-semibold text-gray-800 hover:bg-gray-50 transition-colors">
                Any week
              </button>
              <div className="w-px h-5 bg-gray-300" />
              <button className="flex items-center gap-3 px-3 py-2 rounded-r-full hover:bg-gray-50 transition-colors">
                <span className="text-sm text-gray-500 pl-2">Add guests</span>
                <span className="bg-[#FF385C] text-white rounded-full p-2 group-hover:bg-[#e0314f] transition-colors">
                  <Search className="w-4 h-4" />
                </span>
              </button>
            </div>
          </div>

          {/* Right actions */}
          <div className="flex items-center gap-1">
            <button
              onClick={onDownload}
              className="hidden md:block text-sm font-semibold text-gray-700 hover:bg-gray-100 px-4 py-2 rounded-full transition-colors whitespace-nowrap"
            >
              Download ZIP
            </button>
            <button className="text-sm font-semibold text-gray-700 hover:bg-gray-100 px-4 py-2 rounded-full transition-colors hidden md:block whitespace-nowrap">
              Airbnb your home
            </button>
            <button className="text-gray-700 hover:bg-gray-100 p-2.5 rounded-full transition-colors hidden md:block">
              <Globe className="w-5 h-5" />
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="flex items-center gap-2 border border-gray-300 rounded-full px-3 py-2 hover:shadow-md transition-shadow ml-1"
            >
              {mobileMenuOpen ? (
                <X className="w-4 h-4 text-gray-700" />
              ) : (
                <Menu className="w-4 h-4 text-gray-700" />
              )}
              <div className="bg-gray-500 text-white rounded-full p-0.5">
                <User className="w-5 h-5" />
              </div>
            </button>
          </div>
        </div>

        {/* Stays / Experiences tabs (desktop) */}
        <div className="hidden md:flex items-center justify-center gap-8 pb-3 -mt-1">
          <button
            onClick={() => setActiveTab("stays")}
            className={`text-sm font-semibold pb-1 border-b-2 transition-colors ${
              activeTab === "stays"
                ? "border-gray-900 text-gray-900"
                : "border-transparent text-gray-500 hover:text-gray-700"
            }`}
          >
            Stays
          </button>
          <button
            onClick={() => setActiveTab("experiences")}
            className={`text-sm font-semibold pb-1 border-b-2 transition-colors ${
              activeTab === "experiences"
                ? "border-gray-900 text-gray-900"
                : "border-transparent text-gray-500 hover:text-gray-700"
            }`}
          >
            Experiences
          </button>
        </div>
      </div>

      {/* Mobile search bar */}
      <div className="md:hidden px-4 pb-3">
        <button className="w-full flex items-center gap-3 border border-gray-300 rounded-full px-4 py-3 shadow-sm hover:shadow-md transition-shadow">
          <Search className="w-4 h-4 text-gray-600 flex-shrink-0" />
          <div className="flex flex-col items-start">
            <span className="text-sm font-semibold text-gray-800">Anywhere</span>
            <span className="text-xs text-gray-500">Any week · Add guests</span>
          </div>
        </button>
      </div>

      {/* Mobile dropdown menu */}
      {mobileMenuOpen && (
        <div className="absolute top-full right-4 mt-1 w-56 bg-white rounded-2xl shadow-xl border border-gray-200 py-2 z-50 md:hidden">
          <button className="w-full text-left px-4 py-3 text-sm text-gray-700 hover:bg-gray-50 font-semibold">
            Sign up
          </button>
          <button className="w-full text-left px-4 py-3 text-sm text-gray-700 hover:bg-gray-50">
            Log in
          </button>
          <div className="border-t border-gray-200 my-1" />
          <button className="w-full text-left px-4 py-3 text-sm text-gray-700 hover:bg-gray-50">
            Airbnb your home
          </button>
          <button className="w-full text-left px-4 py-3 text-sm text-gray-700 hover:bg-gray-50">
            Help Center
          </button>
          <div className="border-t border-gray-200 my-1" />
          <button
            onClick={() => { onDownload(); setMobileMenuOpen(false); }}
            className="w-full text-left px-4 py-3 text-sm font-semibold text-[#FF385C] hover:bg-gray-50"
          >
            Download ZIP
          </button>
        </div>
      )}
    </header>
  );
}
