import { useState } from "react";
import { Heart, Star, ChevronLeft, ChevronRight } from "lucide-react";
import type { Listing } from "../data/listings";

interface ListingCardProps {
  listing: Listing;
}

export default function ListingCard({ listing }: ListingCardProps) {
  const [isFav, setIsFav] = useState(listing.isFavorite);
  const [imgIdx, setImgIdx] = useState(0);

  // Simulated multi-image using slight variations
  const images = [
    listing.image,
    listing.image + "&h=600",
    listing.image + "&w=900",
  ];

  const prevImg = (e: React.MouseEvent) => {
    e.preventDefault();
    setImgIdx((i) => (i === 0 ? images.length - 1 : i - 1));
  };

  const nextImg = (e: React.MouseEvent) => {
    e.preventDefault();
    setImgIdx((i) => (i === images.length - 1 ? 0 : i + 1));
  };

  return (
    <div className="group cursor-pointer">
      {/* Image carousel */}
      <div className="relative aspect-square overflow-hidden rounded-2xl bg-gray-200">
        <img
          src={images[imgIdx]}
          alt={listing.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />

        {/* Guest Favorite badge */}
        {listing.isGuestFavorite && (
          <div className="absolute top-3 left-3 bg-white rounded-full px-3 py-1 text-xs font-bold text-gray-800 shadow-md">
            Guest favorite
          </div>
        )}

        {/* Heart */}
        <button
          onClick={(e) => { e.preventDefault(); setIsFav(!isFav); }}
          className="absolute top-3 right-3 p-1.5 rounded-full hover:scale-110 transition-transform"
        >
          <Heart
            className={`w-5 h-5 drop-shadow-md transition-colors ${
              isFav ? "fill-[#FF385C] text-[#FF385C]" : "fill-black/20 text-white"
            }`}
          />
        </button>

        {/* Carousel controls */}
        <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 flex justify-between px-2 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={prevImg}
            className="bg-white rounded-full p-1.5 shadow-md hover:scale-105 transition-transform"
          >
            <ChevronLeft className="w-3 h-3 text-gray-800" />
          </button>
          <button
            onClick={nextImg}
            className="bg-white rounded-full p-1.5 shadow-md hover:scale-105 transition-transform"
          >
            <ChevronRight className="w-3 h-3 text-gray-800" />
          </button>
        </div>

        {/* Dot indicators */}
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1">
          {images.map((_, i) => (
            <div
              key={i}
              className={`rounded-full transition-all ${
                i === imgIdx ? "bg-white w-2 h-2" : "bg-white/60 w-1.5 h-1.5"
              }`}
            />
          ))}
        </div>
      </div>

      {/* Info */}
      <div className="mt-3 px-0.5">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-semibold text-gray-900 text-sm leading-tight truncate">{listing.title}</h3>
          <div className="flex items-center gap-0.5 flex-shrink-0">
            <Star className="w-3.5 h-3.5 fill-gray-900 text-gray-900" />
            <span className="text-sm font-medium text-gray-900">
              {listing.rating === 5.0 ? "5.0" : listing.rating}
            </span>
          </div>
        </div>
        <p className="text-sm text-gray-500 mt-0.5">{listing.location}</p>
        <p className="text-sm text-gray-500">{listing.distance}</p>
        <p className="text-sm text-gray-500">{listing.dates}</p>
        <p className="text-sm text-gray-900 mt-1">
          <span className="font-semibold">${listing.price}</span>
          <span className="text-gray-500"> night</span>
        </p>
      </div>
    </div>
  );
}
