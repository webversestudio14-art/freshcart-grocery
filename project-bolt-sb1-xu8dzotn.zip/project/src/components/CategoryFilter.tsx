import { useRef } from "react";
import {
  LayoutGrid,
  Waves,
  Home,
  Building2,
  Trees,
  Droplets,
  Sun,
  Ship,
  Snowflake,
  Leaf,
  Mountain,
  Palmtree,
  SlidersHorizontal,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { categories } from "../data/listings";

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  LayoutGrid,
  Waves,
  Home,
  Building2,
  Trees,
  Droplets,
  Sun,
  Ship,
  Snowflake,
  Leaf,
  Mountain,
  Palmtree,
};

interface CategoryFilterProps {
  activeCategory: string;
  onCategoryChange: (cat: string) => void;
}

export default function CategoryFilter({ activeCategory, onCategoryChange }: CategoryFilterProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (dir: "left" | "right") => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: dir === "left" ? -240 : 240, behavior: "smooth" });
    }
  };

  return (
    <div className="sticky top-[136px] md:top-[128px] z-40 bg-white border-b border-gray-200">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-3 py-4">
          {/* Left arrow */}
          <button
            onClick={() => scroll("left")}
            className="hidden md:flex flex-shrink-0 items-center justify-center w-8 h-8 border border-gray-300 rounded-full hover:border-gray-900 transition-colors shadow-sm"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          {/* Scrollable categories */}
          <div
            ref={scrollRef}
            className="flex items-center gap-8 overflow-x-auto scrollbar-hide flex-1"
            style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
          >
            {categories.map((cat) => {
              const Icon = iconMap[cat.icon];
              const isActive = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => onCategoryChange(cat.id)}
                  className={`flex flex-col items-center gap-1.5 flex-shrink-0 pb-2 border-b-2 transition-all group ${
                    isActive
                      ? "border-gray-900 text-gray-900 opacity-100"
                      : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 opacity-70 hover:opacity-100"
                  }`}
                >
                  {Icon && <Icon className="w-6 h-6" />}
                  <span className="text-xs font-semibold whitespace-nowrap">{cat.label}</span>
                </button>
              );
            })}
          </div>

          {/* Right arrow */}
          <button
            onClick={() => scroll("right")}
            className="hidden md:flex flex-shrink-0 items-center justify-center w-8 h-8 border border-gray-300 rounded-full hover:border-gray-900 transition-colors shadow-sm"
          >
            <ChevronRight className="w-4 h-4" />
          </button>

          {/* Filters button */}
          <button className="flex-shrink-0 flex items-center gap-2 border border-gray-300 rounded-xl px-4 py-2.5 hover:border-gray-900 transition-colors shadow-sm ml-2">
            <SlidersHorizontal className="w-4 h-4" />
            <span className="text-sm font-semibold whitespace-nowrap">Filters</span>
          </button>
        </div>
      </div>
    </div>
  );
}
