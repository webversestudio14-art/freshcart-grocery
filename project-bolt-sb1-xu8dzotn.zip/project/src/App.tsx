import { useState } from "react";
import Navbar from "./components/Navbar";
import CategoryFilter from "./components/CategoryFilter";
import ListingCard from "./components/ListingCard";
import Footer from "./components/Footer";
import { listings, categories } from "./data/listings";
import { Download } from "lucide-react";

function downloadHTML() {
  const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Airbnb Homepage Clone</title>
  <script src="https://cdn.tailwindcss.com"><\/script>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
    .scrollbar-hide::-webkit-scrollbar { display: none; }
    @keyframes fadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; } }
    .card { animation: fadeIn 0.4s ease forwards; }
  </style>
</head>
<body class="bg-white">
  <header class="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
    <div class="max-w-7xl mx-auto px-6 flex items-center justify-between h-20 gap-4">
      <a href="#" class="flex items-center gap-1">
        <svg viewBox="0 0 32 32" style="width:36px;height:36px;fill:#FF385C"><path d="M16 1c2.008 0 3.463.963 4.751 3.269l.533 1.025c1.954 3.83 6.114 12.54 7.1 14.836l.145.353c.667 1.591.91 2.472.96 3.396l.01.415.001.228c0 4.062-2.877 6.478-6.357 6.478-2.042 0-4.246-1.17-6.22-3.229l-.1-.011-.169.015c-2.084 1.654-4.326 3.225-6.281 3.225-3.48 0-6.357-2.416-6.357-6.478l.001-.228.01-.415c.05-.924.293-1.805.96-3.396l.145-.353c.985-2.296 5.145-11.007 7.1-14.836l.533-1.025C12.537 1.963 13.992 1 16 1z"/></svg>
        <span style="color:#FF385C;font-weight:700;font-size:20px">airbnb</span>
      </a>
      <div class="flex flex-1 max-w-xl">
        <div class="flex items-center w-full border border-gray-300 rounded-full shadow-sm" style="cursor:pointer">
          <button class="flex-1 text-left px-5 py-3 text-sm font-semibold text-gray-800">Anywhere</button>
          <div style="width:1px;height:20px;background:#d1d5db"></div>
          <button class="flex-1 text-left px-5 py-3 text-sm font-semibold text-gray-800">Any week</button>
          <div style="width:1px;height:20px;background:#d1d5db"></div>
          <button class="flex items-center gap-3 px-3 py-2 rounded-r-full">
            <span class="text-sm text-gray-500 pl-2">Add guests</span>
            <span style="background:#FF385C;border-radius:50%;padding:8px;color:white;display:flex">
              <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
            </span>
          </button>
        </div>
      </div>
      <div class="flex items-center gap-2">
        <button class="text-sm font-semibold text-gray-700 px-4 py-2 rounded-full hover:bg-gray-100">Airbnb your home</button>
        <button class="flex items-center gap-2 border border-gray-300 rounded-full px-3 py-2">
          <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
          <div style="background:#6b7280;border-radius:50%;padding:2px;color:white"><svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24"><path d="M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v2.4h19.2v-2.4c0-3.2-6.4-4.8-9.6-4.8z"/></svg></div>
        </button>
      </div>
    </div>
  </header>
  <div class="sticky bg-white border-b border-gray-200" style="top:80px;z-index:40">
    <div class="max-w-7xl mx-auto px-6 flex items-center gap-8 overflow-x-auto py-4" style="scrollbar-width:none">
      ${categories.map(c => `<button onclick="filterCat('${c.id}')" id="cat-${c.id}" style="flex-shrink:0;display:flex;flex-direction:column;align-items:center;gap:6px;padding-bottom:8px;border-bottom:2px solid transparent;color:#6b7280;font-size:12px;font-weight:600;background:none;border-left:none;border-right:none;border-top:none;cursor:pointer" onmouseover="this.style.color='#111'" onmouseout="if(activeCat!='${c.id}')this.style.color='#6b7280'">${c.label}</button>`).join("")}
      <button style="flex-shrink:0;display:flex;align-items:center;gap:8px;border:1px solid #d1d5db;border-radius:12px;padding:10px 16px;font-size:14px;font-weight:600;cursor:pointer;background:white;white-space:nowrap;margin-left:8px">Filters</button>
    </div>
  </div>
  <main class="max-w-7xl mx-auto px-6 py-10">
    <div id="grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:24px">
      ${listings.map(l => `
      <div class="card" data-category="${l.category}" style="cursor:pointer">
        <div style="position:relative;aspect-ratio:1;overflow:hidden;border-radius:16px;background:#e5e7eb">
          <img src="${l.image}" alt="${l.title}" style="width:100%;height:100%;object-fit:cover;transition:transform 0.5s" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'" loading="lazy"/>
          ${l.isGuestFavorite ? `<div style="position:absolute;top:12px;left:12px;background:white;border-radius:20px;padding:4px 12px;font-size:12px;font-weight:700;box-shadow:0 2px 6px rgba(0,0,0,0.15)">Guest favorite</div>` : ""}
          <button onclick="toggleFav(this)" style="position:absolute;top:12px;right:12px;padding:6px;border-radius:50%;border:none;background:transparent;cursor:pointer">
            <svg width="20" height="20" fill="${l.isFavorite ? '#FF385C' : 'rgba(0,0,0,0.2)'}" stroke="white" stroke-width="1.5" viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
          </button>
        </div>
        <div style="margin-top:12px">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px">
            <h3 style="font-weight:600;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#111">${l.title}</h3>
            <div style="display:flex;align-items:center;gap:3px;flex-shrink:0">
              <svg width="14" height="14" fill="currentColor" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
              <span style="font-size:14px;font-weight:500">${l.rating}</span>
            </div>
          </div>
          <p style="font-size:14px;color:#6b7280;margin-top:2px">${l.location}</p>
          <p style="font-size:14px;color:#6b7280">${l.distance}</p>
          <p style="font-size:14px;color:#6b7280">${l.dates}</p>
          <p style="font-size:14px;margin-top:4px"><span style="font-weight:600">$${l.price}</span><span style="color:#6b7280"> night</span></p>
        </div>
      </div>`).join("")}
    </div>
    <div id="empty" style="display:none;text-align:center;padding:80px 0;color:#6b7280;font-size:16px">No listings found for this category.</div>
    <div style="display:flex;justify-content:center;margin-top:56px">
      <button style="display:flex;align-items:center;gap:8px;background:#111;color:white;padding:12px 24px;border-radius:24px;font-weight:600;font-size:14px;border:none;cursor:pointer">
        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polygon points="3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21"/></svg>
        Show map
      </button>
    </div>
  </main>
  <footer style="background:#f9fafb;border-top:1px solid #e5e7eb;margin-top:64px">
    <div class="max-w-7xl mx-auto px-6 py-12">
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:40px;margin-bottom:40px">
        <div><h4 style="font-weight:600;margin-bottom:16px">Support</h4><ul style="list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:12px"><li><a href="#" style="font-size:14px;color:#4b5563;text-decoration:none">Help Center</a></li><li><a href="#" style="font-size:14px;color:#4b5563;text-decoration:none">AirCover</a></li><li><a href="#" style="font-size:14px;color:#4b5563;text-decoration:none">Anti-discrimination</a></li><li><a href="#" style="font-size:14px;color:#4b5563;text-decoration:none">Disability support</a></li></ul></div>
        <div><h4 style="font-weight:600;margin-bottom:16px">Hosting</h4><ul style="list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:12px"><li><a href="#" style="font-size:14px;color:#4b5563;text-decoration:none">Airbnb your home</a></li><li><a href="#" style="font-size:14px;color:#4b5563;text-decoration:none">AirCover for Hosts</a></li><li><a href="#" style="font-size:14px;color:#4b5563;text-decoration:none">Hosting resources</a></li></ul></div>
        <div><h4 style="font-weight:600;margin-bottom:16px">Airbnb</h4><ul style="list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:12px"><li><a href="#" style="font-size:14px;color:#4b5563;text-decoration:none">Newsroom</a></li><li><a href="#" style="font-size:14px;color:#4b5563;text-decoration:none">New features</a></li><li><a href="#" style="font-size:14px;color:#4b5563;text-decoration:none">Careers</a></li></ul></div>
      </div>
      <div style="border-top:1px solid #e5e7eb;padding-top:24px;display:flex;justify-content:space-between;align-items:center">
        <p style="font-size:14px;color:#4b5563">© 2026 Airbnb, Inc. · Privacy · Terms · Sitemap</p>
        <p style="font-size:14px;font-weight:600;color:#374151">English (US) · $ USD</p>
      </div>
    </div>
  </footer>
  <script>
    var activeCat = 'all';
    function toggleFav(btn) {
      var svg = btn.querySelector('svg');
      svg.setAttribute('fill', svg.getAttribute('fill') === '#FF385C' ? 'rgba(0,0,0,0.2)' : '#FF385C');
    }
    function filterCat(id) {
      activeCat = id;
      var cards = document.querySelectorAll('[data-category]');
      var empty = document.getElementById('empty');
      var visible = 0;
      cards.forEach(function(c) {
        var show = id === 'all' || c.dataset.category === id;
        c.style.display = show ? '' : 'none';
        if (show) visible++;
      });
      empty.style.display = visible > 0 ? 'none' : 'block';
      document.querySelectorAll('[id^="cat-"]').forEach(function(b) {
        b.style.borderBottomColor = b.id === 'cat-' + id ? '#111' : 'transparent';
        b.style.color = b.id === 'cat-' + id ? '#111' : '#6b7280';
      });
    }
    filterCat('all');
  <\/script>
</body>
</html>`;

  const blob = new Blob([htmlContent], { type: "text/html" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "airbnb-clone.html";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export default function App() {
  const [activeCategory, setActiveCategory] = useState("all");

  const filtered =
    activeCategory === "all"
      ? listings
      : listings.filter((l) => l.category === activeCategory);

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <Navbar onDownload={downloadHTML} />
      <CategoryFilter activeCategory={activeCategory} onCategoryChange={setActiveCategory} />

      <main className="max-w-[1400px] mx-auto w-full px-4 sm:px-6 lg:px-8 py-10 flex-1">
        {filtered.length === 0 ? (
          <div className="py-24 text-center text-gray-500">
            <p className="text-lg font-medium">No listings found for this category.</p>
            <button
              onClick={() => setActiveCategory("all")}
              className="mt-4 text-sm font-semibold text-gray-900 underline hover:no-underline"
            >
              Clear filter
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-10">
            {filtered.map((listing) => (
              <ListingCard key={listing.id} listing={listing} />
            ))}
          </div>
        )}

        {/* Show map button */}
        <div className="flex justify-center mt-14">
          <button className="flex items-center gap-2 bg-gray-900 text-white px-6 py-3 rounded-full font-semibold text-sm hover:bg-gray-700 transition-all shadow-lg hover:shadow-xl hover:-translate-y-0.5 transform">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
              <polygon points="3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21" />
            </svg>
            Show map
          </button>
        </div>

        {/* Download banner */}
        <div className="mt-16 bg-gradient-to-r from-[#FF385C] to-[#e31c5f] rounded-3xl p-8 flex flex-col sm:flex-row items-center justify-between gap-6 text-white">
          <div>
            <h2 className="text-xl font-bold">Download this project</h2>
            <p className="text-sm mt-1 opacity-90">Get the complete Airbnb homepage clone as a standalone HTML file — fully interactive, no build step needed.</p>
          </div>
          <button
            onClick={downloadHTML}
            className="flex items-center gap-2 bg-white text-[#FF385C] px-6 py-3 rounded-full font-bold text-sm hover:bg-gray-100 transition-colors flex-shrink-0 shadow-md"
          >
            <Download className="w-4 h-4" />
            Download HTML
          </button>
        </div>
      </main>

      <Footer />
    </div>
  );
}
